<?php
session_start();
require_once 'db.php';

// Si déjà connecté, rediriger
if (!empty($_SESSION['user_id'])) {
    header('Location: projetweb.php');
    exit;
}

$erreur = '';
$email  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $mdp   = $_POST['mdp'] ?? '';

    // Validations basiques
    if (!$email) {
        $erreur = 'Renseigne ton adresse email.';
    } elseif (!str_ends_with($email, '@isep.fr') && !str_ends_with($email, '@eleve.isep.fr')) {
        $erreur = 'Utilise ton adresse @isep.fr ou @eleve.isep.fr.';
    } elseif (!$mdp) {
        $erreur = 'Renseigne ton mot de passe.';
    } else {
        // Recherche de l'utilisateur en BDD
        $stmt = $pdo->prepare('SELECT id, firstname, lastname, password FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($mdp, $user['password'])) {
            $erreur = 'Email ou mot de passe incorrect.';
        } else {
            // Connexion réussie — on remplit la session
            $_SESSION['user_id']    = $user['id'];
            $_SESSION['user_email'] = $email;
            $_SESSION['user_name']  = $user['firstname'] . ' ' . $user['lastname'];

            header('Location: projetweb.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion — Fourn'Isep</title>
    <link rel="stylesheet" href="web.css">
</head>
<body class="page-connexion">

    <header>
        <h1><a href="projetweb.php" style="color:inherit;text-decoration:none;">Fourn'<span>Isep</span></a></h1>
        <nav>
            <a href="acheter.php">Acheter</a>
            <a href="vendre.php">Vendre</a>
            <a href="connexion.php">Connexion</a>
            <a href="inscription.php">Inscription</a>
        </nav>
    </header>

    <main class="main-connexion">
        <div class="carte-connexion">
            <div class="connexion-header">
                <h2>Bon retour 👋</h2>
                <p>Connecte-toi avec ton adresse ISEP</p>
            </div>

            <form method="POST" action="connexion.php">

                <div class="champ">
                    <label for="email">Email ISEP</label>
                    <input type="email" id="email" name="email"
                           placeholder="prenom.nom@isep.fr"
                           value="<?= htmlspecialchars($email) ?>">
                </div>

                <div class="champ">
                    <label for="mdp">Mot de passe</label>
                    <input type="password" id="mdp" name="mdp" placeholder="••••••••">
                </div>

                <?php if ($erreur): ?>
                    <span style="display:block; margin-bottom:12px; text-align:center; font-size:0.82rem; color:#c0392b;">
                        <?= htmlspecialchars($erreur) ?>
                    </span>
                <?php endif; ?>

                <a href="#" class="lien-oubli">Mot de passe oublié ?</a>

                <button type="submit" class="btn-connexion">Se connecter</button>

            </form>

            <p class="separation">Pas encore de compte ? <a href="inscription.php">Créer un compte</a></p>
        </div>
    </main>

</body>
</html>
