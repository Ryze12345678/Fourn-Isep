<?php
session_start();
if (!is_dir('uploads/profiles')) {
    mkdir('uploads/profiles', 0777, true);
}

require_once 'db.php';

$erreurs = [];
$succes  = false;
$etape   = isset($_POST['etape']) ? (int)$_POST['etape'] : 1;

// Récupération des valeurs soumises (pour les repopuler)
$prenom = trim($_POST['prenom'] ?? '');
$nom    = trim($_POST['nom']    ?? '');
$cycle  = $_POST['cycle']  ?? '';
$annee  = $_POST['annee']  ?? '';
$email  = trim($_POST['email'] ?? '');
$mdp    = $_POST['mdp']  ?? '';
$mdp2   = $_POST['mdp2'] ?? '';
$bio    = trim($_POST['bio'] ?? '');
$cgv    = isset($_POST['cgv']);

// Mapping cycle → années
$optionsAnnees = [
    'CPA'       => ['P1' => 'P1 — 1ère année', 'P2' => 'P2 — 2ème année'],
    'CII'       => ['B1' => 'B1 — 1ère année', 'B2' => 'B2 — 2ème année'],
    'Ingénieur' => ['I1' => 'I1 — 1ère année', 'I2' => 'I2 — 2ème année', 'I3' => 'I3 — 3ème année'],
    'Bachelor'  => ['BAC1' => 'BAC1 — 1ère année', 'BAC2' => 'BAC2 — 2ème année', 'BAC3' => 'BAC3 — 3ème année'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ── Étape 1 → 2 ──
    if ($etape === 1) {
        if (!$prenom)    $erreurs['etape1'] = 'Merci de remplir tous les champs.';
        elseif (!$nom)   $erreurs['etape1'] = 'Merci de remplir tous les champs.';
        elseif (!$cycle) $erreurs['etape1'] = 'Merci de remplir tous les champs.';
        elseif (!$annee) $erreurs['etape1'] = 'Merci de remplir tous les champs.';
        else             $etape = 2;
    }

    // ── Étape 2 → 3 ──
    elseif ($etape === 2) {
        if (!str_ends_with($email, '@isep.fr') && !str_ends_with($email, '@eleve.isep.fr')) {
            $erreurs['etape2'] = 'Utilise ton adresse @isep.fr ou @eleve.isep.fr.';
        } elseif (strlen($mdp) < 8) {
            $erreurs['etape2'] = 'Le mot de passe doit faire au moins 8 caractères.';
        } elseif ($mdp !== $mdp2) {
            $erreurs['etape2'] = 'Les mots de passe ne correspondent pas.';
        } else {
            // Vérifier que l'email n'est pas déjà utilisé
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $erreurs['etape2'] = 'Cette adresse email est déjà utilisée.';
            } else {
                $etape = 3;
            }
        }
    }

    // ── Étape 3 : inscription finale ──
    elseif ($etape === 3) {
        if (!$cgv) {
            $erreurs['etape3'] = 'Tu dois accepter les conditions pour continuer.';
        } else {
            try {
                $pdo->beginTransaction();

                // 1. Gestion de la photo de profil (optionnel)
                $photoChemin = null;
                if (!empty($_FILES['photo']['tmp_name'])) {
                    $ext         = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
                    $photoChemin = 'uploads/profiles/' . uniqid('pp_') . '.' . $ext;
                    move_uploaded_file($_FILES['photo']['tmp_name'], $photoChemin);
                }

                // 2. INSERT dans users (firstname, lastname, email, password)
                $hash = password_hash($mdp, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare(
                    'INSERT INTO users (firstname, lastname, email, password, role, is_verified)
                     VALUES (?, ?, ?, ?, \'user\', 0)'
                );
                $stmt->execute([$prenom, $nom, $email, $hash]);
                $userId = (int)$pdo->lastInsertId();

                // 3. INSERT dans profiles (user_id, first_name, last_name, bio, profile_picture)
                $stmt = $pdo->prepare(
                    'INSERT INTO profiles (user_id, first_name, last_name, bio, profile_picture)
                     VALUES (?, ?, ?, ?, ?)'
                );
                $stmt->execute([$userId, $prenom, $nom, $bio ?: null, $photoChemin]);

                $pdo->commit();

                // Connexion automatique après inscription
                $_SESSION['user_id']    = $userId;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_name']  = $prenom . ' ' . $nom;

                $succes = true;

            } catch (PDOException $e) {
                $pdo->rollBack();
                $erreurs['etape3'] = 'Une erreur est survenue lors de l\'inscription. Réessaie.';
            }
        }
    }
}

// Helper : conserver la valeur sélectionnée dans un <select>
function selected(string $val, string $ref): string {
    return $val === $ref ? ' selected' : '';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un compte — Fourn'Isep</title>
    <link rel="stylesheet" href="web.css">
    <style>
        .etapes {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-bottom: 28px;
            align-items: center;
        }
        .etape {
            width: 28px; height: 28px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 0.75rem; font-weight: 700;
            font-family: 'Syne', sans-serif;
            transition: all 0.3s ease;
        }
        .etape.active   { background: var(--vert-vinted); color: #fff; }
        .etape.inactive { background: #DDE3EF; color: var(--texte-doux); }
        .etape.done     { background: var(--isep-bleu); color: #fff; }
        .trait {
            flex: 1; height: 2px; background: #DDE3EF;
            border-radius: 2px; max-width: 40px; transition: background 0.3s ease;
        }
        .trait.done { background: var(--isep-bleu); }
        .section-etape { display: none; animation: fadeUp 0.35s ease; }
        .section-etape.visible { display: block; }
        .champ-double {
            display: grid; grid-template-columns: 1fr 1fr;
            gap: 12px; min-width: 0;
        }
        .champ-double .champ { min-width: 0; overflow: hidden; }
        .champ-double .champ select { width: 100%; min-width: 0; overflow: hidden; text-overflow: ellipsis; }
        .indicateur-mdp { margin-top: 6px; height: 4px; border-radius: 4px; background: #DDE3EF; overflow: hidden; }
        .indicateur-mdp-barre { height: 100%; border-radius: 4px; width: 0%; transition: width .3s ease, background .3s ease; }
        .texte-force { font-size: 0.75rem; margin-top: 4px; color: var(--texte-doux); }
        .cgv-ligne { display: flex; align-items: flex-start; gap: 10px; font-size: 0.85rem; color: var(--texte-doux); margin-bottom: 20px; margin-top: 4px; }
        .cgv-ligne input[type="checkbox"] { margin-top: 2px; accent-color: var(--isep-bleu); cursor: pointer; flex-shrink: 0; }
        .cgv-ligne a { color: var(--isep-bleu); text-decoration: none; font-weight: 600; }
        .cgv-ligne a:hover { text-decoration: underline; }
        .message-erreur-php { font-size: 0.82rem; color: #c0392b; margin-bottom: 12px; display: block; }
        .succes-bloc { text-align: center; padding: 20px 0 10px; animation: fadeUp 0.5s ease; }
        .succes-icone { width: 64px; height: 64px; border-radius: 50%; background: #e8fef3; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 2rem; }
        .succes-bloc h3 { font-family: 'Syne', sans-serif; font-size: 1.3rem; color: var(--isep-bleu); margin-bottom: 8px; }
        .succes-bloc p { color: var(--texte-doux); font-size: 0.9rem; margin-bottom: 24px; }
        @media (max-width: 500px) { .champ-double { grid-template-columns: 1fr; } }
    </style>
</head>
<body class="page-connexion">

<header>
    <h1><a href="projetweb.php" style="color:inherit;text-decoration:none;">Fourn'<span>Isep</span></a></h1>
    <nav>
        <a href="acheter.php">Acheter</a>
        <a href="vendre.php">Vendre</a>
        <a href="connexion.php">Connexion</a>
        <a href="inscription.php">Inscription</a>
    </nav>
</header>

<main class="main-connexion">
    <div class="carte-connexion" style="max-width:460px;">

        <?php if ($succes): ?>
        <!-- ── SUCCÈS ── -->
        <div class="succes-bloc">
            <div class="succes-icone">✅</div>
            <h3>Bienvenue sur Fourn'Isep !</h3>
            <p>Ton compte a été créé avec succès.<br>Tu peux maintenant acheter et vendre tes fournitures.</p>
            <a href="projetweb.php" class="btn-connexion" style="display:block;text-align:center;text-decoration:none;">Découvrir les annonces →</a>
        </div>

        <?php else: ?>
        <!-- ── EN-TÊTE ── -->
        <div class="connexion-header">
            <h2>Créer un compte 🎓</h2>
            <p>Rejoins la communauté Fourn'Isep</p>
        </div>

        <!-- ── INDICATEUR D'ÉTAPES ── -->
        <div class="etapes">
            <div class="etape <?= $etape === 1 ? 'active' : 'done' ?>">1</div>
            <div class="trait <?= $etape > 1 ? 'done' : '' ?>"></div>
            <div class="etape <?= $etape === 2 ? 'active' : ($etape > 2 ? 'done' : 'inactive') ?>">2</div>
            <div class="trait <?= $etape > 2 ? 'done' : '' ?>"></div>
            <div class="etape <?= $etape === 3 ? 'active' : 'inactive' ?>">3</div>
        </div>

        <form method="POST" action="inscription.php" enctype="multipart/form-data">

            <!-- Champs cachés pour conserver les données des étapes précédentes -->
            <?php if ($etape >= 2): ?>
                <input type="hidden" name="prenom" value="<?= htmlspecialchars($prenom) ?>">
                <input type="hidden" name="nom"    value="<?= htmlspecialchars($nom) ?>">
                <input type="hidden" name="cycle"  value="<?= htmlspecialchars($cycle) ?>">
                <input type="hidden" name="annee"  value="<?= htmlspecialchars($annee) ?>">
            <?php endif; ?>
            <?php if ($etape >= 3): ?>
                <input type="hidden" name="email" value="<?= htmlspecialchars($email) ?>">
                <input type="hidden" name="mdp"   value="<?= htmlspecialchars($mdp) ?>">
                <input type="hidden" name="mdp2"  value="<?= htmlspecialchars($mdp2) ?>">
            <?php endif; ?>
            <input type="hidden" name="etape" value="<?= $etape ?>">

            <!-- ══ ÉTAPE 1 : Identité ══ -->
            <div class="section-etape <?= $etape === 1 ? 'visible' : '' ?>">
                <div class="champ-double">
                    <div class="champ">
                        <label>Prénom</label>
                        <input type="text" name="prenom" placeholder="Ex : Emma" value="<?= htmlspecialchars($prenom) ?>">
                    </div>
                    <div class="champ">
                        <label>Nom</label>
                        <input type="text" name="nom" placeholder="Ex : Dupont" value="<?= htmlspecialchars($nom) ?>">
                    </div>
                </div>

                <div class="champ-double">
                    <div class="champ">
                        <label>Cycle</label>
                        <select name="cycle" id="cycle" onchange="majAnnees()">
                            <option value="">Sélectionne ton cycle</option>
                            <option value="CPA"<?= selected($cycle,'CPA') ?>>CPA — Prépa Associée (Stanislas)</option>
                            <option value="CII"<?= selected($cycle,'CII') ?>>CII — Prépa Intégrée</option>
                            <option value="Ingénieur"<?= selected($cycle,'Ingénieur') ?>>Cycle Ingénieur</option>
                            <option value="Bachelor"<?= selected($cycle,'Bachelor') ?>>Bachelor</option>
                        </select>
                    </div>
                    <div class="champ">
                        <label>Année</label>
                        <select name="annee" id="annee">
                            <?php if ($cycle && isset($optionsAnnees[$cycle])): ?>
                                <option value="">Sélectionne ton année</option>
                                <?php foreach ($optionsAnnees[$cycle] as $val => $label): ?>
                                    <option value="<?= $val ?>"<?= selected($annee, $val) ?>><?= $label ?></option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option value="">— d'abord le cycle</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>

                <?php if (!empty($erreurs['etape1'])): ?>
                    <span class="message-erreur-php"><?= htmlspecialchars($erreurs['etape1']) ?></span>
                <?php endif; ?>
                <button type="submit" class="btn-connexion">Continuer →</button>
            </div>

            <!-- ══ ÉTAPE 2 : Email & Mot de passe ══ -->
            <div class="section-etape <?= $etape === 2 ? 'visible' : '' ?>">
                <div class="champ">
                    <label>Email ISEP</label>
                    <input type="email" name="email" placeholder="prenom.nom@isep.fr" value="<?= htmlspecialchars($email) ?>">
                </div>

                <div class="champ">
                    <label>Mot de passe</label>
                    <input type="password" name="mdp" id="mdp" placeholder="Minimum 8 caractères" oninput="verifierMdp()">
                    <div class="indicateur-mdp"><div class="indicateur-mdp-barre" id="barre-mdp"></div></div>
                    <span class="texte-force" id="texte-force"></span>
                </div>

                <div class="champ">
                    <label>Confirmer le mot de passe</label>
                    <input type="password" name="mdp2" id="mdp2" placeholder="Répète ton mot de passe">
                </div>

                <?php if (!empty($erreurs['etape2'])): ?>
                    <span class="message-erreur-php"><?= htmlspecialchars($erreurs['etape2']) ?></span>
                <?php endif; ?>
                <button type="submit" class="btn-connexion">Continuer →</button>
                <p class="separation" style="margin-top:0;">
                    <a href="inscription.php">← Retour</a>
                </p>
            </div>

            <!-- ══ ÉTAPE 3 : Finalisation ══ -->
            <div class="section-etape <?= $etape === 3 ? 'visible' : '' ?>">
                <div class="champ">
                    <label>Photo de profil <span style="color:var(--texte-doux);font-weight:400;">(optionnel)</span></label>
                    <input type="file" name="photo" accept="image/*">
                </div>

                <div class="champ">
                    <label>Biographie <span style="color:var(--texte-doux);font-weight:400;">(optionnel)</span></label>
                    <textarea name="bio" placeholder="Ex : I3 passionné de robotique, je vends mes cours B1 et mes TDs..."><?= htmlspecialchars($bio) ?></textarea>
                </div>

                <div class="cgv-ligne">
                    <input type="checkbox" name="cgv" id="cgv" <?= $cgv ? 'checked' : '' ?>>
                    <label for="cgv">J'accepte les <a href="#">conditions d'utilisation</a> de Fourn'Isep et je certifie être étudiant·e à l'ISEP.</label>
                </div>

                <?php if (!empty($erreurs['etape3'])): ?>
                    <span class="message-erreur-php"><?= htmlspecialchars($erreurs['etape3']) ?></span>
                <?php endif; ?>
                <button type="submit" class="btn-connexion">Créer mon compte 🎉</button>
                <p class="separation" style="margin-top:0;">
                    <a href="inscription.php?retour=2">← Retour</a>
                </p>
            </div>

        </form>

        <p class="separation">Déjà un compte ? <a href="connexion.php">Se connecter</a></p>
        <?php endif; ?>

    </div>
</main>

<footer>
    <p>Fourn'<span>Isep</span> — Le vide-grenier des Isepiens 💙</p>
</footer>

<script>
    // Pré-remplissage du select Année si un cycle est déjà sélectionné côté serveur
    const cycleActuel = <?= json_encode($cycle) ?>;
    const anneeActuelle = <?= json_encode($annee) ?>;

    function majAnnees() {
        const cycle = document.getElementById('cycle').value;
        const anneeSelect = document.getElementById('annee');
        const options = {
            'CPA':       [['P1','P1 — 1ère année'], ['P2','P2 — 2ème année']],
            'CII':       [['B1','B1 — 1ère année'], ['B2','B2 — 2ème année']],
            'Ingénieur': [['I1','I1 — 1ère année'], ['I2','I2 — 2ème année'], ['I3','I3 — 3ème année']],
            'Bachelor':  [['BAC1','BAC1 — 1ère année'], ['BAC2','BAC2 — 2ème année'], ['BAC3','BAC3 — 3ème année']],
        };
        if (options[cycle]) {
            anneeSelect.innerHTML = '<option value="">Sélectionne ton année</option>';
            options[cycle].forEach(([val, label]) => {
                const o = document.createElement('option');
                o.value = val;
                o.textContent = label;
                if (val === anneeActuelle) o.selected = true;
                anneeSelect.appendChild(o);
            });
        } else {
            anneeSelect.innerHTML = "<option value=''>— d'abord le cycle</option>";
        }
    }

    // Restaurer les options si on revient sur l'étape 1
    if (cycleActuel) majAnnees();

    function verifierMdp() {
        const mdp = document.getElementById('mdp').value;
        const barre = document.getElementById('barre-mdp');
        const texte = document.getElementById('texte-force');
        if (!barre) return;
        let score = 0;
        if (mdp.length >= 8)           score++;
        if (/[A-Z]/.test(mdp))         score++;
        if (/[0-9]/.test(mdp))         score++;
        if (/[^a-zA-Z0-9]/.test(mdp))  score++;
        const niveaux = [
            { pct: '25%', couleur: '#e74c3c', label: 'Faible' },
            { pct: '50%', couleur: '#e67e22', label: 'Moyen' },
            { pct: '75%', couleur: '#f1c40f', label: 'Bon' },
            { pct: '100%',couleur: '#27ae60', label: 'Excellent' },
        ];
        if (mdp.length === 0) { barre.style.width = '0%'; texte.textContent = ''; return; }
        const n = niveaux[Math.min(score - 1, 3)];
        barre.style.width = n.pct;
        barre.style.background = n.couleur;
        texte.textContent = 'Force : ' + n.label;
    }
</script>

</body>
</html>
