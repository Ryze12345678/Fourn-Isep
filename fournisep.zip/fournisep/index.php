<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fourn'Isep — Le vide-grenier des Isepiens</title>
    <link rel="stylesheet" href="web.css">
</head>
<body>

<header>
    <h1><a href="projetweb.html" style="color:inherit;text-decoration:none;">Fourn'<span>Isep</span></a></h1>
    <nav>
        <a href="acheter.html">Acheter</a>
        <a href="vendre.php">Vendre</a>
        <a href="connexion.php">Connexion</a>
        <a href="inscription.php" class="nav-active">Inscription</a>
    </nav>
</header>

<main>
    <section class="hero">
        <div class="hero-eyebrow">🎓 Réservé aux étudiants ISEP</div>
        <h2>Le vide-grenier<br>des Isepiens</h2>
        <p class="sous-titre">Achète et revends tes fournitures entre étudiants ISEP 📚</p>
        <div class="barre-recherche">
            <input type="text" id="recherche-hero" placeholder="Calculatrice, cours, sac à dos...">
            <button onclick="rechercherHero()">🔍 Rechercher</button>
        </div>
        <div class="hero-stats">
            <div class="hero-stat"><strong>120+</strong>annonces actives</div>
            <div class="hero-stat"><strong>80+</strong>Isepiens inscrits</div>
            <div class="hero-stat"><strong>5 €</strong>prix moyen</div>
        </div>
    </section>

    <div class="categories-section">
        <div class="categories-pills">
            <a href="acheter.html" class="pill">🗂️ Tout voir</a>
            <a href="acheter.html?cat=Calculatrices" class="pill">🖩 Calculatrices</a>
            <a href="acheter.html?cat=Livres" class="pill">📚 Livres & Cours</a>
            <a href="acheter.html?cat=Informatique" class="pill">💻 Informatique</a>
            <a href="acheter.html?cat=Papeterie" class="pill">🖊️ Papeterie</a>
            <a href="acheter.html?cat=Sacs" class="pill">🎒 Sacs & Accessoires</a>
        </div>
    </div>

    <section class="annonces">
        <div class="annonces-header">
            <h2>Dernières fournitures ajoutées</h2>
            <a href="acheter.html" class="voir-tout">Voir tout →</a>
        </div>
        <div class="grille">

            <article class="carte" onclick="ouvrirAnnonce(this)">
                <button class="btn-favori" onclick="toggleFavori(this, event)" aria-label="Ajouter aux favoris">♡</button>
                <div class="carte-img" style="background: linear-gradient(135deg, #e8f0fe, #c2d4f5);">🖩</div>
                <span class="carte-badge badge-info">Calculatrices</span>
                <h3>Calculatrice TI-Nspire</h3>
                <p class="prix">4 €</p>
                <p class="vendeur">Ines.B</p>
                <button onclick="event.stopPropagation(); ouvrirAnnonce(this.closest('.carte'))">Voir l'annonce</button>
            </article>

            <article class="carte" onclick="ouvrirAnnonce(this)">
                <button class="btn-favori" onclick="toggleFavori(this, event)" aria-label="Ajouter aux favoris">♡</button>
                <div class="carte-img" style="background: linear-gradient(135deg, #e8fef3, #b8f0d8);">📐</div>
                <span class="carte-badge badge-success">Papeterie</span>
                <h3>Kit de géométrie complet</h3>
                <p class="prix">5 €</p>
                <p class="vendeur">Camélia.S</p>
                <button onclick="event.stopPropagation(); ouvrirAnnonce(this.closest('.carte'))">Voir l'annonce</button>
            </article>

            <article class="carte" onclick="ouvrirAnnonce(this)">
                <button class="btn-favori" onclick="toggleFavori(this, event)" aria-label="Ajouter aux favoris">♡</button>
                <div class="carte-img" style="background: linear-gradient(135deg, #fff4e8, #ffd9a8);">📚</div>
                <span class="carte-badge badge-warning">Livres & Cours</span>
                <h3>Cours B1 imprimés</h3>
                <p class="prix">3 €</p>
                <p class="vendeur">Lina.B</p>
                <button onclick="event.stopPropagation(); ouvrirAnnonce(this.closest('.carte'))">Voir l'annonce</button>
            </article>

            <article class="carte" onclick="ouvrirAnnonce(this)">
                <button class="btn-favori" onclick="toggleFavori(this, event)" aria-label="Ajouter aux favoris">♡</button>
                <div class="carte-img" style="background: linear-gradient(135deg, #f4e8fe, #ddb8f5);">💻</div>
                <span class="carte-badge badge-purple">Informatique</span>
                <h3>Souris sans fil</h3>
                <p class="prix">15 €</p>
                <p class="vendeur">Axel.L</p>
                <button onclick="event.stopPropagation(); ouvrirAnnonce(this.closest('.carte'))">Voir l'annonce</button>
            </article>

            <article class="carte" onclick="ouvrirAnnonce(this)">
                <button class="btn-favori" onclick="toggleFavori(this, event)" aria-label="Ajouter aux favoris">♡</button>
                <div class="carte-img" style="background: linear-gradient(135deg, #feeae8, #f5c2b8);">🎒</div>
                <span class="carte-badge badge-danger">Sacs & Accessoires</span>
                <h3>Sac à dos Eastpak</h3>
                <p class="prix">25 €</p>
                <p class="vendeur">Eunice.S</p>
                <button onclick="event.stopPropagation(); ouvrirAnnonce(this.closest('.carte'))">Voir l'annonce</button>
            </article>

            <article class="carte" onclick="ouvrirAnnonce(this)">
                <button class="btn-favori" onclick="toggleFavori(this, event)" aria-label="Ajouter aux favoris">♡</button>
                <div class="carte-img" style="background: linear-gradient(135deg, #e8fefe, #b8eef5);">🖊️</div>
                <span class="carte-badge badge-success">Papeterie</span>
                <h3>Lot de stylos Stabilo</h3>
                <p class="prix">2 €</p>
                <p class="vendeur">Dania.G</p>
                <button onclick="event.stopPropagation(); ouvrirAnnonce(this.closest('.carte'))">Voir l'annonce</button>
            </article>

        </div>
    </section>

    <section class="section-confiance">
        <div class="confiance-inner">
            <div class="confiance-item">
                <div class="confiance-icone">🔒</div>
                <h4>100 % ISEP</h4>
                <p>Réservé aux adresses @eleve.isep.fr et @isep.fr — communauté vérifiée.</p>
            </div>
            <div class="confiance-item">
                <div class="confiance-icone">♻️</div>
                <h4>Économique & éco</h4>
                <p>Donne une seconde vie à tes fournitures et fais des économies.</p>
            </div>
            <div class="confiance-item">
                <div class="confiance-icone">⚡</div>
                <h4>Simple & rapide</h4>
                <p>Publie une annonce en moins de 2 minutes, échange sur le campus.</p>
            </div>
            <div class="confiance-item">
                <div class="confiance-icone">🤝</div>
                <h4>Entre étudiants</h4>
                <p>Pas d'intermédiaire, pas de frais — juste des Isepiens qui s'entraident.</p>
            </div>
        </div>
    </section>
</main>

<footer>
    <p>Fourn'<span>Isep</span> — Le vide-grenier des Isepiens 💙</p>
    <div class="footer-links">
        <a href="#">À propos</a>
        <a href="#">Conditions d'utilisation</a>
        <a href="#">Contact</a>
    </div>
</footer>

<!-- MODALE ANNONCE -->
<div id="modale-overlay" class="modale-overlay" onclick="fermerModale()">
    <div class="modale-carte" onclick="event.stopPropagation()">
        <button class="modale-fermer" onclick="fermerModale()" aria-label="Fermer">✕</button>
        <div id="modale-img" class="modale-img"></div>
        <div class="modale-body">
            <span id="modale-badge" class="carte-badge"></span>
            <h3 id="modale-titre"></h3>
            <p id="modale-prix" class="modale-prix"></p>
            <p id="modale-vendeur" class="modale-vendeur-ligne"></p>
            <p id="modale-desc" class="modale-desc"></p>
            <div class="modale-actions">
                <button class="btn-connexion" style="margin-bottom:0;" onclick="window.location.href='connexion.php'">✉️ Contacter le vendeur</button>
                <button class="btn-outline" onclick="fermerModale()">Fermer</button>
            </div>
        </div>
    </div>
</div>

<script>
    const descriptions = {
        'Calculatrice TI-Nspire': 'TI-Nspire CX II en très bon état. Quelques rayures légères sur le boîtier mais écran parfait. Fournie avec le câble USB et la housse. Idéale pour les B1 et B2.',
        'Kit de géométrie complet': 'Compas, règle, équerre, rapporteur et crayon de précision. Marque Maped. Utilisé seulement un semestre, comme neuf.',
        'Cours B1 imprimés': 'Tous les cours de B1 imprimés recto-verso et reliés : Maths, Physique, Info. Très propres, quelques annotations au crayon.',
        'Souris sans fil': 'Souris Logitech M185 sans fil, récepteur USB inclus. Pile AA fournie. Fonctionne parfaitement, vendue car passage au trackpad.',
        'Sac à dos Eastpak': "Sac à dos Eastpak 30L, coloris marine. Compartiment laptop 15\", très solide. Légèrement usé sur les bretelles mais impeccable.",
        'Lot de stylos Stabilo': "Lot de 10 stylos Stabilo Boss Original, couleurs variées. Tous neufs, emballage d'origine légèrement abîmé.",
    };

    function rechercherHero() {
        const q = document.getElementById('recherche-hero').value.trim();
        window.location.href = q ? 'acheter.html?q=' + encodeURIComponent(q) : 'acheter.html';
    }
    document.getElementById('recherche-hero').addEventListener('keydown', e => { if (e.key === 'Enter') rechercherHero(); });

    function toggleFavori(btn, event) {
        event.stopPropagation();
        const actif = btn.classList.toggle('actif');
        btn.textContent = actif ? '♥' : '♡';
        btn.setAttribute('aria-label', actif ? 'Retirer des favoris' : 'Ajouter aux favoris');
    }

    function ouvrirAnnonce(carte) {
        const titre = carte.querySelector('h3').textContent;
        const prix = carte.querySelector('.prix').textContent;
        const vendeur = carte.querySelector('.vendeur').textContent;
        const imgEl = carte.querySelector('.carte-img');
        const badge = carte.querySelector('.carte-badge');

        document.getElementById('modale-titre').textContent = titre;
        document.getElementById('modale-prix').textContent = prix;
        document.getElementById('modale-vendeur').textContent = '🧑‍🎓 Vendu par ' + vendeur;
        document.getElementById('modale-desc').textContent = descriptions[titre] || 'Article en bon état, vendu par un étudiant ISEP.';
        const modImg = document.getElementById('modale-img');
        modImg.textContent = imgEl.textContent;
        modImg.style.cssText = imgEl.style.cssText + '; font-size:4.5rem; display:flex; align-items:center; justify-content:center; height:180px; border-radius:20px 20px 0 0;';
        const badgeEl = document.getElementById('modale-badge');
        badgeEl.className = badge.className;
        badgeEl.textContent = badge.textContent;

        document.getElementById('modale-overlay').classList.add('visible');
        document.body.style.overflow = 'hidden';
    }

    function fermerModale() {
        document.getElementById('modale-overlay').classList.remove('visible');
        document.body.style.overflow = '';
    }

    document.addEventListener('keydown', e => { if (e.key === 'Escape') fermerModale(); });
</script>

</body>
</html>
