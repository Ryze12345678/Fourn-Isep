<?php
require_once 'config.php';

$nouveau_hash = password_hash("TON_MOT_DE_PASSE_ICI", PASSWORD_DEFAULT);

mysqli_query($con, "UPDATE utilisateurs SET mdp='$nouveau_hash' WHERE email='TON_EMAIL_ICI'");

echo "Mot de passe mis à jour !";
?>