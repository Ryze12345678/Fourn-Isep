<?php
session_start();

if (empty($_SESSION['user_id'])) {
    header('Location: connexion.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendre — Fourn'Isep</title>
    <link rel="stylesheet" href="web.css">
</head>
<body>

<header>
    <h1>
        <a href="projetweb.php" style="color:inherit;text-decoration:none;">
            Fourn'<span>Isep</span>
        </a>
    </h1>
</header>

<main style="padding:40px;max-width:600px;margin:auto;">

    <h2>Publier une annonce</h2>

    <form>

        <div class="champ">
            <label>Titre</label>
            <input type="text">
        </div>

        <div class="champ">
            <label>Prix</label>
            <input type="number">
        </div>

        <div class="champ">
            <label>Description</label>
            <textarea></textarea>
        </div>

        <button class="btn-connexion">
            Publier
        </button>

    </form>

</main>

</body>
</html>