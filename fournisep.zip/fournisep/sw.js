const CACHE_NAME = 'fournisep-cache-v1';
const assetsToCache = [
  'projetweb.html',
  'web.css',
  'manifest.json',
  'icon-512.png'
];

// Installation : Mise en cache des ressources principales
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(assetsToCache);
    })
  );
});

// Interception des requêtes : Répond avec le cache ou va chercher sur le réseau
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      return cachedResponse || fetch(event.request);
    })
  );
});