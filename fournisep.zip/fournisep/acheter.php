<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acheter — Fourn'Isep</title>
    <link rel="stylesheet" href="web.css">
</head>
<body>

<header>
    <h1>
        <a href="projetweb.php" style="color:inherit;text-decoration:none;">
            Fourn'<span>Isep</span>
        </a>
    </h1>
</header>

<main style="padding:40px;text-align:center;">
    <h2>Page Acheter</h2>
    <p>Les annonces seront affichées ici.</p>
</main>

</body>
</html>