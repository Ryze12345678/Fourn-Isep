<?php
$nom_serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "";
$nom_base_donnees = "form";
$con = mysqli_connect($nom_serveur, $utilisateur, $mot_de_passe, $nom_base_donnees);
?>