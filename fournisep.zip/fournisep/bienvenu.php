<?php
session_start();
if(!isset($_SESSION['email'])){
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenue — Fourn'Isep</title>
    <link rel="stylesheet" href="web.css">
</head>
<body>

    <header>
        <h1><a href="projetweb.html" style="color:inherit;text-decoration:none;">Fourn'<span>Isep</span></a></h1>
        <nav>
            <a href="acheter.html">Acheter</a>
            <a href="vendre.php">Vendre</a>
            <a href="deconnexion.php">Déconnexion</a>
        </nav>
    </header>

    <main style="display:flex; justify-content:center; align-items:center; min-height:calc(100vh - 68px);">
        <div class="carte-connexion" style="text-align:center;">
            <div class="succes-icone" style="margin:0 auto 20px;">👋</div>
            <h2 style="font-family:'Syne',sans-serif; color:var(--isep-bleu); margin-bottom:8px;">
                Bonjour, <?php echo htmlspecialchars($_SESSION['email']); ?> !
            </h2>
            <p style="color:var(--texte-doux); margin-bottom:28px;">Tu es maintenant connecté·e à Fourn'Isep.</p>
            <a href="acheter.html" class="btn-connexion" style="text-decoration:none; display:flex;">Voir les annonces →</a>
            <a href="vendre.php" style="display:block; text-align:center; margin-top:12px; color:var(--isep-bleu-clair); font-size:0.9rem; text-decoration:none;">📦 Déposer une annonce</a>
        </div>
    </main>

</body>
</html>
