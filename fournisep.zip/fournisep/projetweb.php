<?php
session_start();

$userConnected = !empty($_SESSION['user_id']);
$userName = $_SESSION['user_name'] ?? '';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fourn'Isep</title>
    <link rel="stylesheet" href="web.css">

    
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#0056b3">
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('sw.js')
                    .then((reg) => console.log('Service Worker enregistré avec succès ! scope:', reg.scope))
                    .catch((err) => console.log('Échec de l\'enregistrement du Service Worker :', err));
            });
        }
    </script>
</head>
<body>

<header>
 <h1>
        <a href="projetweb.php" style="color:inherit;text-decoration:none;">
            Fourn'<span>Isep</span>
        </a>
    </h1>

    <nav>
        <a href="acheter.php">Acheter</a>
        <a href="vendre.php">Vendre</a>

        <?php if ($userConnected): ?>
            <span class="bonjour">👋 <?= htmlspecialchars($userName) ?></span>
            <a href="logout.php">Déconnexion</a>
        <?php else: ?>
            <a href="connexion.php">Connexion</a>
            <a href="inscription.php">Inscription</a>
        <?php endif; ?>
    </nav>   
</header>

<main>

<section class="hero">
    <h2>Le vide-grenier des Isepiens</h2>

    <p class="sous-titre">
        Achète et revends tes fournitures entre étudiants ISEP 🎓
    </p>

    <div class="barre-recherche">
        <input type="text" id="recherche-hero" placeholder="Que recherches-tu ?">
        <button onclick="rechercherHero()">Rechercher</button>
    </div>
</section>

<section class="annonces">
    <h2>Dernières fournitures ajoutées</h2>

    <div class="grille">

            <article class="carte" onclick="ouvrirAnnonce(this)">
            <div class="carte-img" style="background: linear-gradient(135deg, #e8f0fe, #c2d4f5);">🖩</div>
            <span class="carte-badge badge-info">Calculatrices</span>
            <h3>Calculatrice TI-Nspire</h3>
            <p class="prix">4 €</p>
            <p class="vendeur">Ines.B</p>
            <button onclick="event.stopPropagation(); ouvrirAnnonce(this.closest('.carte'))">
                Voir l'annonce
            </button>
        </article>

        <article class="carte" onclick="ouvrirAnnonce(this)">
            <div class="carte-img" style="background: linear-gradient(135deg, #fff4e8, #ffd9a8);">📚</div>
            <span class="carte-badge badge-warning">Livres & Cours</span>
            <h3>Cours B1 imprimés</h3>
            <p class="prix">3 €</p>
            <p class="vendeur">Lina.B</p>
            <button onclick="event.stopPropagation(); ouvrirAnnonce(this.closest('.carte'))">
                Voir l'annonce
            </button>
        </article>

    </div>
</section>

</main>

<footer>
    <p>Fourn'<span>Isep</span> — Le vide-grenier des Isepiens 💙</p>
</footer>

<script>
function rechercherHero() {
    const q = document.getElementById('recherche-hero').value.trim();

    window.location.href = q
        ? 'acheter.php?q=' + encodeURIComponent(q)
        : 'acheter.php';
}

function ouvrirAnnonce(carte) {
    const titre = carte.querySelector('h3').textContent;
    alert('Annonce : ' + titre);
}
</script>

</body>
</html>